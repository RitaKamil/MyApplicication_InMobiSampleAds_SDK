package com.inmobi.banner;

public interface PlacementId {
    long YOUR_PLACEMENT_ID = 1473189489298L;
}
