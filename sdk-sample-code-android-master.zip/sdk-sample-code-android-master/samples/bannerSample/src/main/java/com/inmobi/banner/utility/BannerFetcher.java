package com.inmobi.banner.utility;

public interface BannerFetcher {

    void onFetchSuccess();

    void onFetchFailure();
}