package com.inmobi.interstitial.sample;

public interface PlacementId {
    // PLID for Interstitial full screen
    //long YOUR_PLACEMENT_ID = 1476878485960L;

    // PLID for Rewarded video
    long YOUR_PLACEMENT_ID = 1475973082314L;
}
