package com.inmobi.interstitial.sample;

public interface InterstitialFetcher {

    void onFetchSuccess();

    void onFetchFailure();
}