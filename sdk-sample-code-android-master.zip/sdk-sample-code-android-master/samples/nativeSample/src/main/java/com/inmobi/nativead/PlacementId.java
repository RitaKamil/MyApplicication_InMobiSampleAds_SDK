package com.inmobi.nativead;

/**
 * Placement ID to be used to render the Native ads.
 */
public interface PlacementId {
   long YOUR_PLACEMENT_ID_HERE = 1492763427180L;
}
